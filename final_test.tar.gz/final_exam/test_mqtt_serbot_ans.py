from serbot_mini.driving import Driving
from serbot_mini.battery import Battery
from serbot_mini.ultrasonic import Ultrasonic
from serbot_mini.imu import Imu

import paho.mqtt.client as mqtt
import time


TOPIC_DRV_ROOT = "SerBotMini/driving"
TOPIC_SEN_ROOT = "SerBotMini/sensors"

#문제-1 시작.
TOPIC_DRV_SPEED = 
TOPIC_DRV_DIRECTION = 
TOPIC_DRV_STEERING = 

TOPIC_SEN_BATTERY = 
TOPIC_SEN_ULTRASONIC = 
TOPIC_SEN_IMU = 
#문제-1 끝.

speed = 0
direction = None
steering = 0.0


def on_connect(client, sensors, flags, rc):
    if rc == 0:
        client.subscribe(TOPIC_DRV_ROOT + "/+")
        client.message_callback_add(TOPIC_DRV_SPEED, on_speed)
        client.message_callback_add(TOPIC_DRV_DIRECTION, on_direction)
        client.message_callback_add(TOPIC_DRV_STEERING, on_steering)

        client.subscribe(TOPIC_SEN_ROOT + "/+")
        #문제-2 시작.
        client.message_callback_add()
        client.message_callback_add()
        client.message_callback_add()
        #문제-2 끝.

def on_speed(client, serbot, message):
    global speed

    speed = int(message.payload)
    if speed == 0:
        serbot['drv'].stop()
    elif 0 < speed <= 100:
        serbot['drv'].speed = speed
   
def on_direction(client, serbot, message):
    global direction

    direction = message.payload.decode()
    if direction == "forward":
        serbot['drv'].forward()
    elif direction == "backward":
        serbot['drv'].backward()
    
def on_steering(client, serbot, message):
    global steering

    steering = float(message.payload)
    if -1.0 <= steering <= 1.0:
        serbot['drv'].steering = steering

def on_battery(client, serbot, message):
    #문제-3-1 시작.
    cmd = 
    #문제-3-1 끝.

    if "start" in cmd:
        serbot['battery'].callback(__on_battery, param=client)
    elif "stop" in cmd:
        serbot['battery'].stop()
    
def on_ultrasonic(client, serbot, message):
    #문제-3-2 시작.
    cmd = 
    #문제-3-2 끝.

    if "start" in cmd:
        serbot['ultrasonic'].callback(__on_ultrasonic, param=client)
    elif "stop" in cmd:
        serbot['ultrasonic'].stop()

def on_imu(client, serbot, message):
    #문제-3-3 시작.
    cmd = 
    #문제-3-3 끝.
    
    if "start" in cmd:    
        serbot['imu'].callback(__on_imu, param=client)
    elif "stop" in cmd:
        serbot['imu'].stop()

    
def __on_battery(data, client):
    client.publish(TOPIC_SEN_BATTERY, str(data))

def __on_ultrasonic(data, client):
    client.publish(TOPIC_SEN_ULTRASONIC, str(data))

def __on_imu(data, client):
    client.publish(TOPIC_SEN_IMU, str(data))


def main():
    serbot = {'drv':Driving(), 'battery':Battery(), 'ultrasonic':Ultrasonic(), 'imu':Imu()}

    #문제-4 시작.
    client = 
    #문제-4 끝.

    client.on_connect = on_connect

    client.connect("127.0.0.1")
    client.loop_start()

    try:
        while True:
            time.sleep(0.1)
    except KeyboardInterrupt:
        #문제-5 시작.
        serbot
        serbot
        serbot
        serbot
        #문제-5 끝.

if __name__ == "__main__":
    main()
