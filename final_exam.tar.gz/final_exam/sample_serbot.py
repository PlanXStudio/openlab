from serbot_mini.driving import Driving
from serbot_mini.battery import Battery
from serbot_mini.ultrasonic import Ultrasonic
from serbot_mini.imu import Imu

import time

def on_battery(n):
    print("battery: ", n)
    time.sleep(1)

def on_ultrasonic(n):
    print("ultrasonic: ", n)

def on_imu(n):
    print("imu: ", n)

def main():
    drv = Driving()
    
    battery = Battery()
    ultrasoinc = Ultrasonic()
    imu = Imu()

    battery.callback(on_battery)
    ultrasoinc.callback(on_ultrasonic)
    imu.callback(on_imu)
    
    drv.speed = 50

    drv.backward()
    time.sleep(3)
    drv.forward()
    time.sleep(3)
    drv.steering = -0.8
    time.sleep(3)
    drv.steering = 0.5
    time.sleep(3)

    drv.stop()

    input()

    battery.stop()
    ultrasoinc.stop()
    imu.stop()

if __name__ == "__main__":
    main()