import paho.mqtt.client as mqtt

id = None
client = None

CHATT_TOPIC = "SerBotMini/human/chatt"

def send_message():
    msg = input() 
    payload = id + ': ' + msg
    client.publish(CHATT_TOPIC, payload, 1)


def on_connect(client, userdata, flags, rc):
    if rc == 0:
        send_message()

def on_publish(client, userdata, mid):
    send_message()

def main():
    global id, client

    id = input("Please enter your session name: ")    

    client = mqtt.Client(id, False)

    client.on_connect = on_connect
    client.on_publish = on_publish

    client.will_set(CHATT_TOPIC, id + " exit", 1)

    client.connect("127.0.0.1")
    try:
        client.loop_forever()
    except KeyboardInterrupt:
        pass

    
if __name__ == "__main__":
    main()
