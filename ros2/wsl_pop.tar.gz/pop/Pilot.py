import random
import time
import logging

class AutoCar:
    def __init__(self):
        self._steer = 0.0
        self.logger = logging.getLogger()
        self.logger.setLevel(logging.INFO)
                
        formatter = logging.Formatter('|>>>AUTOCAR<<<|%(asctime)s|%(levelname)s|%(message)s')
        stream_handler = logging.StreamHandler()
        stream_handler.setFormatter(formatter)
        self.logger.addHandler(stream_handler)

    def setSensorStatus(*args, **kwargs):
        pass

    def getAccel(self, axis=None):
        return (random.uniform(-9.8, 9.8), random.uniform(-9.8, 9.8), random.uniform(-9.8, 9.8))
    
    def getGyro(self, axis=None):
        return (random.uniform(-9.8, 9.8), random.uniform(-9.8, 9.8), random.uniform(-9.8, 9.8))

    def getQuat(self, axis=None):
        return (random.uniform(-9.8, 9.8), random.uniform(-9.8, 9.8), random.uniform(-9.8, 9.8), random.uniform(-9.8, 9.8))

    def getBattery(self):
        return (random.uniform(14.5, 19.6), random.uniform(13.5, 70.0))

    def setSpeed(self, speed):
        self.logger.info(f"driving {speed = }")

    def forward(self):
        self.logger.info("driving forward")

    def backward(self):
        self.logger.info("driving backward")

    def stop(self):
        self.logger.info("driving stop")

    @property
    def steering(self):
        return self._steer

    @steering.setter
    def steering(self, steering):
        self.logger.info(f"driving {steering = }")

    def setLamp(self, front, rear):
        if front:
            fs = "front on"
        else:
            fs = "front off"
        if rear:
            rs = "rear  on"
        else:
            rs = "rear  off"

        self.logger.info("LED " + fs + ' ' + rs)

    def getUltrasonic(self):
        return ((random.randint(5, 180), random.randint(5, 180), random.randint(5, 180)), (random.randint(5, 180), random.randint(5, 180)))


if __name__ == "__main__":
    car = AutoCar()

    car.setSpeed(30)
    car.forward()
    time.sleep(3)
    car.steering = -1.0
    time.sleep(3)
    car.backward()
    time.sleep(3)
    car.forward()
    car.setSpeed(90)
    time.sleep(3)
    car.steering = 1.0
    time.sleep(3)
    car.steering = 0.0
    time.sleep(3)
    car.stop()

