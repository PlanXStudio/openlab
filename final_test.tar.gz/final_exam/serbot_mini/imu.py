import struct
import threading
from .Can import Can

class Imu:
    ACT_IMU =           0x020
    BRD_CALIBRATION =   0x120
    BRD_ACCEL =         0x121
    BRD_MAGNETIC =      0x122
    BRD_GYRO =          0x123
    BRD_EULER =         0x124
    BRD_GRAVITY =       0x125
    BRD_QUAT =          0x126

    def __init__(self, dev='can0'):
        self.__can = Can()
        self.__func = None
        self.__param = None
        self.__thread = None
        self.__stop = False

        self.__imu = { Imu.BRD_ACCEL:None,
                       Imu.BRD_MAGNETIC:None,
                       Imu.BRD_GYRO:None,
                       Imu.BRD_EULER:None,
                       Imu.BRD_GRAVITY:None,
                       Imu.BRD_QUAT:None }

        self.__can.filter(Imu.BRD_CALIBRATION)
        for f in self.__imu.keys():
            self.__can.filter(f)

    def __del__(self):
        self.stop()

    def __calc_xyz(self, payload):
        xyz_scale = struct.unpack('hhhB',struct.pack('BBBBBBB', *payload))
        xyz = tuple(map(lambda n: n / xyz_scale[-1], xyz_scale[:-1]))

        return xyz

    def __calc_gyro_xyz(self, payload):
        xyz_scale = struct.unpack('hhhB',struct.pack('BBBBBBB', *payload))
        xyz = tuple(map(lambda n: n * 0.001090830782496456, xyz_scale[:-1]))

        return xyz

    def __calc_wxyz(self, payload):
        raw_wxyz = struct.unpack('hhhh',struct.pack('BBBBBBBB', *payload))
        wxyz = tuple(map(lambda n: n / (1<<14), raw_wxyz))

        return wxyz

    def __callback(self):
        while not self.__stop:
            self.__imu = self.__imu.fromkeys(self.__imu.keys(), None)

            while not all(self.__imu.values()) and not self.__stop:
                id, dlc, payload = self.__can.recv(timeout=0.1)
                if not payload:
                    continue

                if id != Imu.BRD_QUAT:
                    if id != Imu.BRD_GYRO:
                        self.__imu[id] = self.__calc_xyz(payload)
                    else:
                        self.__imu[id] = self.__calc_gyro_xyz(payload)
                else:
                    self.__imu[id] = self.__calc_wxyz(payload)

            if not all(self.__imu.values()):
                return

            if self.__param:
                self.__func(tuple(self.__imu.values()), self.__param)
            else:
                self.__func(tuple(self.__imu.values()))

    def calibration(self):
        self.__can.send(Imu.ACT_IMU, [0x01, 0x00])
        id, dlc, payload = self.__can.recv(timeout=2.0)
        return (payload[0] & 0x03, (payload[0] >> 2) & 0x03, (payload[0] >> 4) & 0x03, (payload[0] >> 6) & 0x03)

    def accel(self):
        self.__can.send(Imu.ACT_IMU, [0x02, 0x00])
        id, dlc, payload = self.__can.recv(timeout=2.0)
        return self.__calc_xyz(payload)

    def magnetic(self):
        self.__can.send(Imu.ACT_IMU, [0x04, 0x00])
        id, dlc, payload = self.__can.recv(timeout=2.0)
        return self.__calc_xyz(payload)

    def gyro(self):
        self.__can.send(Imu.ACT_IMU, [0x08, 0x00])
        id, dlc, payload = self.__can.recv(timeout=2.0)
        return self.__calc_gyro_xyz(payload)

    def euler(self):
        self.__can.send(Imu.ACT_IMU, [0x10, 0x00])
        id, dlc, payload = self.__can.recv(timeout=2.0)
        return self.__calc_xyz(payload)

    def gravity(self):
        self.__can.send(Imu.ACT_IMU, [0x20, 0x00])
        id, dlc, payload = self.__can.recv(timeout=2.0)
        return self.__calc_xyz(payload)
    
    def quat(self):
        self.__can.send(Imu.ACT_IMU, [0x40, 0x00])
        id, dlc, payload = self.__can.recv(timeout=2.0)
        return self.__calc_wxyz(payload)

    def callback(self, func, repeat=1, param=None):
        if not self.__thread:
            self.__func = func
            self.__param = param

            self.__stop = False
            self.__thread = threading.Thread(target=self.__callback)
            self.__thread.start()

            self.__can.send(Imu.ACT_IMU, [0x7E, repeat & 0xFF])

    def stop(self):
        if self.__thread:
           self.__stop = True
           self.__thread = None

           self.__can.send(Imu.ACT_IMU, [0x7E, 00])
