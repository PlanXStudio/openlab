#include <vector>
#include <cmath>
#include <cassert>
#include <cstring>

#include "lidar2d.h"

constexpr double deg2rad = M_PI/180.0;

Lidar2D::Lidar2D()
{
  _lidar = *createLidarDriver();
}

Lidar2D::~Lidar2D()
{
  _lidar->stop();
  _lidar->disconnect();

  delete _lidar;
}

bool Lidar2D::connect(const char *port, int baudrate)
{
  auto channel = *createSerialPortChannel(port, baudrate);
  assert(channel);

  return SL_IS_OK(_lidar->connect(channel));
}

void Lidar2D::stopScan()
{
  _lidar->stop();
}

void Lidar2D::startScan()
{
  std::vector<LidarScanMode> scanModes;

  _lidar->getAllSupportedScanModes(scanModes);
  _lidar->startScanExpress(false, scanModes[2].id);
}

std::vector<std::vector<double>> Lidar2D::getData(bool quality)
{
  int quality_t;
  std::vector<double> sample(3);
  std::vector<std::vector<double>> output;
  sl_lidar_response_measurement_node_hq_t nodes[8*1024];
  size_t nodes_count = sizeof(nodes)/sizeof(nodes[0]);

  if (SL_IS_OK(_lidar->grabScanDataHq(nodes, nodes_count))) {
    _lidar->ascendScanData(nodes, nodes_count);
    output.reserve(nodes_count);

    for (int pos = 0; pos < (int)nodes_count; pos++) {
      quality_t = nodes[pos].quality >> SL_LIDAR_RESP_MEASUREMENT_QUALITY_SHIFT;
      if (quality_t > 0 || !quality) {
        sample.at(0) = nodes[pos].angle_z_q14 * 90.f / (1 << 14);
        sample.at(1) = nodes[pos].dist_mm_q2/4.0f;
        sample.at(2) = quality_t;
        output.push_back(sample);
      }
    }
  }

  return output;
}