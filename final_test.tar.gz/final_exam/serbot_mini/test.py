import struct
import unittest

class Imu:
    def calc_xyz(self, payload):
        xyz_scale = struct.unpack('hhhB',struct.pack('BBBBBBB', *payload))
        return tuple(map(lambda n: n / xyz_scale[-1], xyz_scale[:-1]))

class ImuUnitTest(unittest.TestCase):
    def setUp(self):
        self.imu = Imu()

    def test_calc_xyz1(self):
        result = (-0.31, -0.07, 10.1)
        self.assertEqual(self.imu.calc_xyz([225, 255, 249, 255, 242, 3, 100]), result)

    def test_calc_xyz2(self):
        result = (120.5, 1.1875, 12.0625)
        self.assertEqual(self.imu.calc_xyz([8, 20, 19, 0, 193, 0, 16]), result)

    def tearDown(self):
        del self.imu

if __name__ == '__main__':
    unittest.main()