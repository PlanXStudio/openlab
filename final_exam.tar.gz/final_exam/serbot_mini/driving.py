from .driving_base import DrivingBase
import math

def map(x, in_min, in_max, out_min, out_max):
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;


class Driving(DrivingBase):
    ACT_PID = 0x012
    PID_ON = 0xFF
    PID_OFF = 0x00

    MAX_STEERING_ANGLE = 55

    def __init__(self, dev='can0'):
        super().__init__(dev)
        self.__pid = False
        self.steering = 0.0

    def forward(self, speed=None):
        self.move(0, speed)

    def backward(self, speed=None):
        self.move(180, speed)

    @property
    def steering(self):
        return ((self.wheel_vec[0] - DrivingBase.WHEEL_CENTER) / 100) * -1

    @steering.setter
    def steering(self, r):
        assert(-1.0 <= r <= 1.0)

        self.wheel_vec[0] = int(round(map(r, -1.0, 1.0, (DrivingBase.WHEEL_CENTER + self.speed), (DrivingBase.WHEEL_CENTER - self.speed)), 1))
        self.transfer()

    @property
    def pid(self):
        return self.__pid

    @pid.setter
    def pid(self, on):
        self.__pid = on
        self.__can.send(Driving.ACT_PID, Driving.PID_ON if self.__pid else Driving.PID_OFF)
