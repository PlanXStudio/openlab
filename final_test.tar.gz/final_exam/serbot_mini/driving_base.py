import math
from .Can import Can

class DrivingBase:
    WHEEL_ID =  0x010
    WHEEL_POS = 0x07
    WHEEL_CENTER = 100

    WHEEL_CALIBRATION = 1.15

    def __init__(self, dev='can0'):
        self.__angle  = 0
        self.__can = Can(dev)
        self.__stop()

    def __stop(self):
        self.__speed = 0  # recommend 60 ~ 100
        self.wheel_vec = [DrivingBase.WHEEL_CENTER, DrivingBase.WHEEL_CENTER, DrivingBase.WHEEL_CENTER]

    def __move(self):
        if (self.__angle == 0) or (self.__angle == 180):
            weight = self.speed * DrivingBase.WHEEL_CALIBRATION
        else:
            weight = self.speed

        Vx = -1 * math.sin(math.radians(self.__angle)) * weight
        Vy = math.cos(math.radians(self.__angle)) * weight

        self.wheel_vec[0] = DrivingBase.WHEEL_CENTER - round(-1 * Vx)
        self.wheel_vec[1] = DrivingBase.WHEEL_CENTER - round((1/2) * Vx + (math.sqrt(3) / 2) * Vy)
        self.wheel_vec[2] = DrivingBase.WHEEL_CENTER - round((1/2) * Vx - (math.sqrt(3) / 2) * Vy)

        self.transfer()

    def transfer(self):
        payload = [DrivingBase.WHEEL_POS] + self.wheel_vec
        self.__can.send(DrivingBase.WHEEL_ID, payload)

    def move(self, angle, speed=None):
        if speed:
            self.speed = speed

        self.__angle = angle
        self.__move()

    def stop(self):
        self.__stop()
        self.transfer()

    @property
    def speed(self):
        return self.__speed

    @speed.setter
    def speed(self, speed):
        self.__speed = speed
        self.__move()
