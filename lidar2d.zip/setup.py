from distutils.core import setup, Extension

lidar2d_module = Extension('_lidar2d',
                            sources=['lidar2d_wrap.cxx', 'lidar2d.cpp'],
				extra_objects=["libsl_lidar_sdk.a"],
				extra_compile_args=['-lpthread', '-lstdc++'],
                           )

setup (name = 'lidar2d',
       version = '1.0',
       author = "PlanX-Lab",
       description = """lidar2d Python Binder""",
       ext_modules = [lidar2d_module],
       py_modules = ["lidar2d"],
       )
