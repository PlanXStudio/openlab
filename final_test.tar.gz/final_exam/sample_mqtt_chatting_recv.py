import paho.mqtt.client as mqtt
import sys

id = None
client = None

CHATT_TOPIC = "SerBotMini/human/chatt"

def on_connect(client, userdata, flags, rc):
    if rc == 0:
        client.subscribe(CHATT_TOPIC, 1)

def on_message(client, userdata, message):
    data = message.payload.decode()

    if data[:len(id)] != id:
        print(">>>", data)


def main():
    global id, client

    id = input("Please enter your session name: ")    

    client = mqtt.Client(id, False)

    client.on_connect = on_connect
    client.on_message = on_message

    client.will_set(CHATT_TOPIC, id + " exit", 1)

    client.connect("127.0.0.1")

    try:
        client.loop_forever()
    except KeyboardInterrupt:
        pass

    
if __name__ == "__main__":
    main()
