import can

class Can:
    def __init__(self, dev='can0'):
        self.bus = can.interface.Bus(channel=dev, bustype='socketcan', bitrate=500000)
        self.__filter = []

    def __del__(self):
        self.bus.shutdown()

    def filter(self, id, mask=0x7FF):
        for i, f in enumerate(self.__filter):
            if f['can_id'] == id:
                if mask == 0:
                    del self.__filter[i]
                    return
                else:
                    self.__filter[i]['can_mask'] = mask
                    break
        else:
            self.__filter.append({'can_id':id, 'can_mask':mask})
        self.bus.set_filters(self.__filter)


    def send(self, id, payload):
        msg = can.Message(arbitration_id=id, data=payload, is_extended_id=False)
        self.bus.send(msg)

    def recv(self, timeout=None):
        msg = self.bus.recv(timeout=timeout)
        if msg:
            return msg.arbitration_id, msg.dlc, list(msg.data)
        else:
            return (None, None, None)
