#!/usr/bin/python3

import subprocess
import os

p = subprocess.Popen(['swig',
                      '-c++',
                      '-python',
                      'lidar2d.i'])
p.wait()

p = subprocess.Popen(['python3',
                      'setup.py',
                      'build_ext',
                      '--inplace'])
p.wait()

for file in os.listdir(os.getcwd()):
    if file.find('_lidar2d.cpython') >= 0:
        os.rename(os.path.join(os.getcwd(), file), os.path.join(os.getcwd(), '_lidar2d.so'))
        break
