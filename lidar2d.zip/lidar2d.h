#include "../sdk/include/sl_lidar.h"

using namespace sl;
using namespace std;

class Lidar2D {
  public:
    Lidar2D();
    ~Lidar2D();

    bool connect(const char *port, int baudrate);

    void startScan();
    void stopScan();
    
    std::vector<std::vector<double>> getData(bool quality=true);

  private:
    ILidarDriver* _lidar;
};
