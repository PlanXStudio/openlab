import threading
from .Can import Can

class Ultrasonic:
    ACT_ULTRASONIC = 0x030
    BRD_ULTRASONIC = 0x130

    def __init__(self, dev='can0'):
        self.__can = Can()
        self.__func = None
        self.__param = None
        self.__thread = None
        self.__stop = False

        self.__can.filter(Ultrasonic.BRD_ULTRASONIC)

    def __del__(self):
        self.stop()

    def __callback(self):
        while not self.__stop:
            id, dlc, payload = self.__can.recv(timeout=0.1)
            if not payload:
                continue

            if self.__param:
                self.__func((payload[0], payload[1], payload[2]), self.__param)
            else:
                self.__func((payload[0], payload[1], payload[2]))

    def read(self):
        self.__can.send(Ultrasonic.ACT_ULTRASONIC, [0x07, 0x00])
        id, dlc, payload = self.__can.recv(timeout=2.0)
        return payload[0], payload[1], payload[2]

    def callback(self, func, repeat=1, param=None):
        if not self.__thread:
            self.__func = func
            self.__param = param

            self.__stop = False
            self.__thread = threading.Thread(target=self.__callback)
            self.__thread.start()

            self.__can.send(Ultrasonic.ACT_ULTRASONIC, [0x07, repeat & 0xFF])

    def stop(self):
        if self.__thread:
            self.__stop = True
            self.__thread = None

            self.__can.send(Ultrasonic.ACT_ULTRASONIC, [0x07, 00])
